export const environment = {
  production: true,
  apiURL:'http://localhost:3000/api/',
  offset : 0,
  count : 5,
  selected : [5, 10, 50],
  homepage_title:'MEAN MOVIES',
  users_component_title:'List of Users',
  token_storage_key:'meanMoviesToken'

};
