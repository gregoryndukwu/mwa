export const environment = {
  production: false,
  apiURL:'http://localhost:3000/api/',
  offset : 0,
  count : 5,
  selected : [5, 10, 50],
  token_storage_key:'meanMoviesToken',
  users_component_title:'List of Users',
  homepage_title:'MEAN MOVIES'
};
